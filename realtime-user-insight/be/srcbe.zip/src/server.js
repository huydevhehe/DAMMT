import express from "express";
import cors from "cors";
import http from "http";
import { Server } from "socket.io";
import dotenv from "dotenv";
import { pool } from "./db.js";
import eventRoutes from "./routes/events.js";
import metricsRoutes from "./routes/metrics.js";

dotenv.config();

const app = express();
app.use(express.json());

app.use(cors({
  origin: "http://localhost:8080",
  methods: ["GET", "POST"],
  credentials: true,
}));

// API routes
app.use("/api/events", eventRoutes);
app.use("/api/metrics", metricsRoutes);

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:8080",
    methods: ["GET", "POST"],
  },
});

// 🟢 Khi client FE kết nối socket
io.on("connection", (socket) => {
  console.log("🟢 Client connected");

  // Khi FE gửi event
  socket.on("track_event", async (event) => {
    try {
      // Ghi event mới vào DB
      await pool.query(
        `INSERT INTO events (type, x, y, page, timestamp)
         VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)`,
        [event.type, event.x, event.y, event.page]
      );

      // Emit realtime event cho biểu đồ
      io.emit("new_event", event);

      // 🔹 Tính lại metrics tổng quan
      const metrics = await pool.query(`
        SELECT 
          COUNT(*) AS total_events,
          COUNT(DISTINCT page) AS active_users,
          COUNT(DISTINCT type) AS sessions,
          ROUND(EXTRACT(EPOCH FROM (NOW() - MIN(timestamp))))::INT AS avg_duration
        FROM events;
      `);

      // 🔹 Gửi cập nhật realtime cho dashboard
      io.emit("update_metrics", { metrics: metrics.rows[0] });

      console.log("📊 Metrics updated:", metrics.rows[0]);

    } catch (err) {
      console.error("❌ Insert error:", err);
    }
  });

  socket.on("disconnect", () => console.log("🔴 Client disconnected"));
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
