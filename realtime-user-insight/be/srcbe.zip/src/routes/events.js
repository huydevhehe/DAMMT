import express from "express";
import { pool } from "../db.js";

const router = express.Router();

// 🟢 API: Lấy 50 event mới nhất (cho biểu đồ realtime)
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM events ORDER BY id DESC LIMIT 50"
    );
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching events:", err);
    res.status(500).json({ error: "Database error" });
  }
});

// 🟢 API: Ghi event mới từ FE hoặc Postman
router.post("/", async (req, res) => {
  try {
    const { type, x, y, page } = req.body;

    // 🧠 Ghi dữ liệu vào DB, dùng CURRENT_TIMESTAMP để tránh lỗi epoch
    const result = await pool.query(
      `INSERT INTO events (type, x, y, page, timestamp)
       VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
       RETURNING *`,
      [type, x, y, page]
    );

    console.log("📩 New event saved via API:", result.rows[0]);
    res.status(201).json({
      message: "Event added successfully",
      event: result.rows[0],
    });
  } catch (err) {
    console.error("❌ Insert error:", err);
    res.status(500).json({ error: "Insert failed" });
  }
});

export default router;
