import express from "express";
import { pool } from "../db.js";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const totalEvents = await pool.query("SELECT COUNT(*) FROM events");
    res.json({ totalEvents: totalEvents.rows[0].count });
  } catch (err) {
    console.error("❌ Metrics error:", err);
    res.status(500).json({ error: "Database error" });
  }
});

export default router;
