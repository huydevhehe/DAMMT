import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import apiClient from "@/lib/apiClient";

const EventsTable = () => {
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    loadEvents();

    const socket = io("http://localhost:4000");
    socket.on("new_event", (event) => {
      setEvents((prev) => [event, ...prev].slice(0, 50));
    });

    return () => socket.disconnect();
  }, []);

  const loadEvents = async () => {
    const res = await apiClient.get("/events");
    setEvents(res.data);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow border">
      <h2 className="font-semibold mb-4">Sự kiện gần đây</h2>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b">
            <th>Thời gian</th>
            <th>Loại</th>
            <th>Trang</th>
          </tr>
        </thead>
        <tbody>
          {events.map((e) => (
            <tr key={e.id} className="border-b hover:bg-gray-50">
              <td>{new Date(e.timestamp).toLocaleString()}</td>
              <td>{e.type}</td>
              <td>{e.page}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EventsTable;
