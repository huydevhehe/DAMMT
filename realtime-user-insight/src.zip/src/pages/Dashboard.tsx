import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import apiClient from "@/lib/apiClient";
import MetricsCard from "@/components/dashboard/MetricsCard";
import EventsTable from "@/components/dashboard/EventsTable";
import HeatmapView from "@/components/dashboard/HeatmapView";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Users, Activity, MousePointer2, Clock } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const Dashboard = () => {
  // --- State thống kê tổng ---
  const [metrics, setMetrics] = useState({
    active_users: 0,
    total_sessions: 0,
    total_events: 0,
    avg_duration: 0,
  });

  // --- Dữ liệu biểu đồ realtime ---
  const [chartData, setChartData] = useState<{ time: string; count: number }[]>([]);

  // --- Danh sách sự kiện gần đây ---
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    // Load dữ liệu ban đầu
    loadMetrics();
    loadInitialEvents();

    // Kết nối socket.io tới server backend
    const socket = io("http://localhost:4000", {
      transports: ["websocket"],
    });

    socket.on("connect", () => console.log("🟢 Đã kết nối realtime tới server"));

    // Khi có cập nhật metrics realtime
    socket.on("update_metrics", (data) => {
      console.log("📊 Cập nhật metrics:", data);
      setMetrics(data);
    });

    // Khi có event mới → cập nhật chart, bảng, metrics
    socket.on("new_event", (event) => {
      console.log("⚡ Nhận event mới:", event);
      updateChart(event);
      addEventRow(event);
      // metrics cũng thay đổi
      loadMetrics();
    });

    socket.on("disconnect", () => console.log("🔴 Mất kết nối socket"));

    // cleanup khi unmount
    return () => socket.disconnect();
  }, []);

  // --- Lấy dữ liệu metrics ban đầu ---
  const loadMetrics = async () => {
    try {
      const res = await apiClient.get("/metrics");
      setMetrics(res.data);
    } catch (error) {
      console.error("❌ Lỗi tải metrics:", error);
    }
  };

  // --- Lấy danh sách sự kiện để hiển thị và vẽ biểu đồ ---
  const loadInitialEvents = async () => {
    try {
      const res = await apiClient.get("/events");
      const data = res.data || [];
      setEvents(data);
      const grouped = groupByMinute(data);
      setChartData(grouped);
    } catch (err) {
      console.error("❌ Lỗi tải dữ liệu events:", err);
    }
  };

  // --- Gom nhóm dữ liệu theo phút (vẽ biểu đồ) ---
  const groupByMinute = (events: any[]) => {
    const map = new Map<string, number>();
    events.forEach((e) => {
      const time = new Date(e.timestamp).toLocaleTimeString("vi-VN", {
        hour12: false,
      });
      map.set(time, (map.get(time) || 0) + 1);
    });
    return Array.from(map.entries()).map(([time, count]) => ({ time, count }));
  };

  // --- Khi có event mới → cập nhật biểu đồ realtime ---
  const updateChart = (event: any) => {
    const time = new Date(event.timestamp).toLocaleTimeString("vi-VN", {
      hour12: false,
    });
    setChartData((prev) => {
      const existing = prev.find((d) => d.time === time);
      if (existing) {
        return prev.map((d) =>
          d.time === time ? { ...d, count: d.count + 1 } : d
        );
      }
      return [...prev.slice(-29), { time, count: 1 }];
    });
  };

  // --- Khi có event mới → thêm vào bảng sự kiện ---
  const addEventRow = (event: any) => {
    setEvents((prev) => [event, ...prev.slice(0, 49)]); // chỉ giữ 50 dòng gần nhất
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <h1 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <Activity className="w-6 h-6 text-blue-500" /> Analytics Dashboard
      </h1>

      {/* --- Các ô thống kê --- */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricsCard title="Người dùng hoạt động" value={metrics.active_users} icon={<Users />} />
        <MetricsCard title="Phiên làm việc" value={metrics.total_sessions} icon={<Activity />} />
        <MetricsCard title="Tổng sự kiện" value={metrics.total_events} icon={<MousePointer2 />} />
        <MetricsCard title="Thời gian TB (giây)" value={metrics.avg_duration} icon={<Clock />} />
      </div>

      {/* --- Biểu đồ realtime --- */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h2 className="text-lg font-semibold mb-4">
          Biểu đồ realtime (Tổng sự kiện)
        </h2>
        <div style={{ width: "100%", height: 350 }}>
          <ResponsiveContainer>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="count"
                stroke="#2563eb"
                strokeWidth={2}
                dot={false}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* --- Tabs (Bảng sự kiện và Heatmap) --- */}
      <Tabs defaultValue="events" className="space-y-6">
        <TabsList>
          <TabsTrigger value="events">Sự kiện</TabsTrigger>
          <TabsTrigger value="heatmap">Heatmap</TabsTrigger>
        </TabsList>

        <TabsContent value="events">
          <EventsTable events={events} /> {/* truyền dữ liệu realtime vào bảng */}
        </TabsContent>

        <TabsContent value="heatmap">
          <HeatmapView />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;
